//: [⇐ Previous: 01 - Introduction](@previous)
//: ## Episode 02: Enumerations







//: [⇒ Next: 03 - Challenge - Enumerations](@next)
