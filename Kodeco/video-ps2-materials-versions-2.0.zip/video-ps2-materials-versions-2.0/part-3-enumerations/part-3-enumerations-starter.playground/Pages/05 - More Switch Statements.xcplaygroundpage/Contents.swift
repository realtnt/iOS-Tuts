//: [⇐ Previous: 04 - Switch Statements](@previous)
//: ## Episode 05: More Switch Statements

//: Switching on values




//: Switching on expressions




//: Switching on multiple values





//: [⇒ Next: 06 - Challenge - Switch Statements](@next)

