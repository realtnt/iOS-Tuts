//: [⇐ Previous: 01 - Introduction](@previous)
//: ## Episode 02: Stored Properties





//: [⇒ Next: 03 - Computed Properties](@next)
