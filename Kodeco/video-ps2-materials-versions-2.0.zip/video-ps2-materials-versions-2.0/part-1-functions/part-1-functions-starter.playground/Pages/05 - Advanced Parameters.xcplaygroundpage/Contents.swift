//: [⇐ Previous: 04 - Overloading](@previous)
//: ## Episode 05 - Advanced Parameters

// --------------------------------------
let passingGrade = 50
let jessyGrade = 49
let ozmaGrade = 87
let ozmaAllGrades = [60, 96, 87, 42]
// --------------------------------------

//: ### Variadic Parameters



//: ### Inout Parameters

// --------------------------------------
var count = 0
// --------------------------------------




//: [⇒ Next: 06 - Challenge - Overloads & Parameters](@next)
