//: [⇐ Previous: 05 - Challenge: Properties](@previous)
//: ## Episode 06: Methods




//: [⇒ Next: 07 - Challenge - Methods](@next)
