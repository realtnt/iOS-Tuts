//: [⇐ Previous: 06 - Challenge - Switch Statements](@previous)
//: ## Episode 07: Enumerations with Associated Values




//: [⇒ Next: 08 - Conclusion](@next)
